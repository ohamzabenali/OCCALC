"use client"

import { useState } from "react"

const Calculator = () => {
  const [display, setDisplay] = useState("0")
  const [prevValue, setPrevValue] = useState(null)
  const [operator, setOperator] = useState(null)
  const [waitingForOperand, setWaitingForOperand] = useState(false)

  const inputDigit = (digit) => {
    if (waitingForOperand) {
      setDisplay(String(digit))
      setWaitingForOperand(false)
    } else {
      setDisplay(display === "0" ? String(digit) : display + digit)
    }
  }

  const inputDecimal = () => {
    if (waitingForOperand) {
      setDisplay("0.")
      setWaitingForOperand(false)
    } else if (display.indexOf(".") === -1) {
      setDisplay(display + ".")
    }
  }

  const clear = () => {
    setDisplay("0")
    setPrevValue(null)
    setOperator(null)
    setWaitingForOperand(false)
  }

  const performOperation = (nextOperator) => {
    const inputValue = Number.parseFloat(display)

    if (prevValue === null) {
      setPrevValue(inputValue)
    } else if (operator) {
      const currentValue = prevValue || 0
      const newValue = calculate(currentValue, inputValue, operator)

      setPrevValue(newValue)
      setDisplay(String(newValue))
    }

    setWaitingForOperand(true)
    setOperator(nextOperator)
  }

  const calculate = (a, b, op) => {
    switch (op) {
      case "+":
        return a + b
      case "-":
        return a - b
      case "*":
        return a * b
      case "/":
        return a / b
      default:
        return b
    }
  }

  const handleEquals = () => {
    if (!operator) return

    const inputValue = Number.parseFloat(display)
    const currentValue = prevValue || 0
    const newValue = calculate(currentValue, inputValue, operator)

    setDisplay(String(newValue))
    setPrevValue(null)
    setOperator(null)
    setWaitingForOperand(true)
  }

  const buttonClass =
    "w-16 h-16 m-1 rounded-full text-2xl font-bold shadow-lg focus:outline-none focus:ring-2 focus:ring-offset-2 transition-colors duration-200"

  return (
    <div className="bg-gray-800 p-6 rounded-3xl shadow-2xl">
      <div className="bg-gray-200 w-full p-4 rounded-2xl mb-4">
        <div className="text-right text-4xl font-bold text-gray-800">{display}</div>
      </div>
      <div className="grid grid-cols-4 gap-2">
        <button onClick={clear} className={`${buttonClass} bg-red-500 hover:bg-red-600 text-white`}>
          C
        </button>
        <button onClick={() => inputDigit(7)} className={`${buttonClass} bg-blue-500 hover:bg-blue-600 text-white`}>
          7
        </button>
        <button onClick={() => inputDigit(8)} className={`${buttonClass} bg-blue-500 hover:bg-blue-600 text-white`}>
          8
        </button>
        <button onClick={() => inputDigit(9)} className={`${buttonClass} bg-blue-500 hover:bg-blue-600 text-white`}>
          9
        </button>
        <button
          onClick={() => performOperation("/")}
          className={`${buttonClass} bg-yellow-500 hover:bg-yellow-600 text-white`}
        >
          /
        </button>
        <button onClick={() => inputDigit(4)} className={`${buttonClass} bg-blue-500 hover:bg-blue-600 text-white`}>
          4
        </button>
        <button onClick={() => inputDigit(5)} className={`${buttonClass} bg-blue-500 hover:bg-blue-600 text-white`}>
          5
        </button>
        <button onClick={() => inputDigit(6)} className={`${buttonClass} bg-blue-500 hover:bg-blue-600 text-white`}>
          6
        </button>
        <button
          onClick={() => performOperation("*")}
          className={`${buttonClass} bg-yellow-500 hover:bg-yellow-600 text-white`}
        >
          *
        </button>
        <button onClick={() => inputDigit(1)} className={`${buttonClass} bg-blue-500 hover:bg-blue-600 text-white`}>
          1
        </button>
        <button onClick={() => inputDigit(2)} className={`${buttonClass} bg-blue-500 hover:bg-blue-600 text-white`}>
          2
        </button>
        <button onClick={() => inputDigit(3)} className={`${buttonClass} bg-blue-500 hover:bg-blue-600 text-white`}>
          3
        </button>
        <button
          onClick={() => performOperation("-")}
          className={`${buttonClass} bg-yellow-500 hover:bg-yellow-600 text-white`}
        >
          -
        </button>
        <button onClick={() => inputDigit(0)} className={`${buttonClass} bg-blue-500 hover:bg-blue-600 text-white`}>
          0
        </button>
        <button onClick={inputDecimal} className={`${buttonClass} bg-blue-500 hover:bg-blue-600 text-white`}>
          .
        </button>
        <button onClick={handleEquals} className={`${buttonClass} bg-green-500 hover:bg-green-600 text-white`}>
          =
        </button>
        <button
          onClick={() => performOperation("+")}
          className={`${buttonClass} bg-yellow-500 hover:bg-yellow-600 text-white`}
        >
          +
        </button>
      </div>
    </div>
  )
}

export default Calculator

