import Calculator from "../components/Calculator"

export default function Home() {
  return (
    <main className="flex min-h-screen flex-col items-center justify-center bg-gradient-to-br from-purple-400 to-pink-500">
      <Calculator />
    </main>
  )
}

